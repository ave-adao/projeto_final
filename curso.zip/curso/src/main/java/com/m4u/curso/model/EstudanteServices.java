package com.m4u.curso.model;
import com.m4u.curso.view.EstudanteRepository;
import com.m4u.curso.model.Estudante;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudanteServices {
    @Autowired
    private EstudanteRepository estudanteRepository;

    public Estudante createEstudante (Estudante estudante){
        return estudanteRepository.save(estudante);
    }
    public List<Estudante>getEstudanteList(){
        return estudanteRepository.findAll();
    }
    public Estudante getEstudanteById(int id){
        return estudanteRepository.findById(id).orElse(null);
    }
    public Estudante updateEstudanteById(Estudante estudante){
        Optional<Estudante> estudanteFound = estudanteRepository.findById(estudante.getIdEstudante());
        if(estudanteFound.isPresent()) {
            Estudante estudanteUpdate = estudanteFound.get();
            estudanteUpdate.setNome(estudante.getNome());
            estudanteUpdate.setIdade(estudante.getIdade());
            return estudanteRepository.save(estudante);
        }else {
            return null;
        }
        }
    public String deleteEstudanteById(int id) {
        estudanteRepository.deleteById(id);
        return "Estudante"+ id +" deleted";
    }
    }

