package com.m4u.curso.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="adress")
public class Endereco {
    @Id
    @GeneratedValue
    private int idAdress;
    private String street;
    private String city;
    private String state;
    private String country;
    private Integer zipcode;

    public Endereco(String logradouro, String cidade, String estado, String pais, Integer cep) {
        this.street = logradouro;

        this.city = cidade;
        this.state = estado;
        this.country = pais;
        this.zipcode = cep;
    }

    public int getIdAdress() {
        return idAdress;
    }

    public void setIdAdress(int idAdress) {
        this.idAdress = idAdress;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

        public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPais() {
        return country;
    }

    public void setPais(String pais) {
        this.country = pais;
    }

    public Integer getZipcode() {
        return zipcode;
    }

    public void setZipcode(Integer zipcode) {
        this.zipcode = zipcode;
    }

    @Override
    public String toString() {
        return "endereco{" +
                "id=" + idAdress +
                ", logradora='" + street + '\'' +
                ", Cidade='" + city +
                '\'' +
                ", Estado='" + state +
                '\'' +
                ", CEP='" + zipcode +
                '\'' +
                ", País='" + country +
                '}';
    }
}
