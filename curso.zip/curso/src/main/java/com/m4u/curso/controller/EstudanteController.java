package com.m4u.curso.controller;
import com.m4u.curso.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class EstudanteController {
@Autowired
    private EstudanteServices estudanteServices;
    @GetMapping("/estudantes")
public ResponseEntity<List<Estudante>> getAllEstudante() {
        return ResponseEntity.ok(estudanteServices.getEstudanteList());
    }

    @GetMapping("/estudante/{id}")
    public ResponseEntity<Estudante> getEstudanteById(@PathVariable int id) {
        return ResponseEntity.ok().body(this.estudanteServices.getEstudanteById(id));
    }

    @PostMapping("addEstudante")
    public ResponseEntity<Estudante> addUser(@RequestBody Estudante estudante) {
        return ResponseEntity.ok(this.estudanteServices.createEstudante(estudante));
    }

    @PutMapping("/updateEstudantes/")
    public ResponseEntity<Estudante> updateUser(@RequestBody Estudante estudante) {
        return ResponseEntity.ok().body(this.estudanteServices.updateEstudanteById(estudante));
    }

    @DeleteMapping("/deleteEstudante/{id}")
    public HttpStatus deleteUser(@PathVariable int id) {
        this.estudanteServices.deleteEstudanteById(id);
        return HttpStatus.OK;
    }
}
