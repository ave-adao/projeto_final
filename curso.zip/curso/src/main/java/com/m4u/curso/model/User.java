package com.m4u.curso.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="user")
public class User {
    @Id
    @GeneratedValue
    private int idUser;
    private String user;
    private String password;


    private int status;

    public User(String email, String senha) {
        this.user = email;
        this.password = senha;
    }

    public User() {
    }

    public int getId() {
        return idUser;
    }

    public void setId(int id) {
        this.idUser = id;
    }

    public String getEmail() {
        return user;
    }

    public void setEmail(String email) {
        this.user = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + idUser +
                ", email='" + user + '\'' +
                ", senha='" + password + '}';
    }

}
