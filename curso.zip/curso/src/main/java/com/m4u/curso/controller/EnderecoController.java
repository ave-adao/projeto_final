package com.m4u.curso.controller;
import com.m4u.curso.model.Endereco;
import com.m4u.curso.model.EnderecoServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class EnderecoController {
@Autowired
    private EnderecoServices enderecoServices;
    @GetMapping("/enderecos")

    public ResponseEntity<List<Endereco>> getAllUsers() {
        return ResponseEntity.ok(enderecoServices.getEnderecoList());
    }

    @GetMapping("/endereco/{id}")
    public ResponseEntity<Endereco> getUserById(@PathVariable int id) {
        return ResponseEntity.ok().body(this.enderecoServices.getEnderecoById(id));
    }

    @PostMapping("addEndereco")
    public ResponseEntity<Endereco> addUser(@RequestBody Endereco endereco) {
        return ResponseEntity.ok(this.enderecoServices.createEndereco(endereco));
    }

    @PutMapping("/updateEndereco/")
    public ResponseEntity<Endereco> updateUser(@RequestBody Endereco endereco) {
        return ResponseEntity.ok().body(this.enderecoServices.updateEnderecoById(endereco));
    }

    @DeleteMapping("/deleteEndereco/{id}")
    public HttpStatus deleteUser(@PathVariable int id) {
        this.enderecoServices.deleteEnderecoById(id);
        return HttpStatus.OK;
    }
}
